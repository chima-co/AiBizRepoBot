const { Telegraf, Markup, session } = require("telegraf");
const express = require("express");
require("dotenv").config();

// ─────────────────────────────────────────────
//  PRODUCT CATALOG  (edit freely)
// ─────────────────────────────────────────────
const CATALOG = {
  "👗 Fashion": [
    { id: "f1", name: "Classic White Tee", price: 3500, stock: 50, emoji: "👕" },
    { id: "f2", name: "Denim Jacket",       price: 15000, stock: 20, emoji: "🧥" },
    { id: "f3", name: "Ankara Dress",       price: 12000, stock: 15, emoji: "👗" },
    { id: "f4", name: "Sneakers (Unisex)",  price: 18000, stock: 30, emoji: "👟" },
  ],
  "💄 Beauty": [
    { id: "b1", name: "Glow Serum",         price: 6500,  stock: 40, emoji: "✨" },
    { id: "b2", name: "Matte Lipstick Set", price: 4500,  stock: 60, emoji: "💋" },
    { id: "b3", name: "Sunscreen SPF 50",   price: 5000,  stock: 35, emoji: "🌞" },
  ],
  "📱 Electronics": [
    { id: "e1", name: "Wireless Earbuds",   price: 22000, stock: 25, emoji: "🎧" },
    { id: "e2", name: "Phone Stand",        price: 3000,  stock: 80, emoji: "📱" },
    { id: "e3", name: "Power Bank 20000mAh",price: 14000, stock: 18, emoji: "🔋" },
  ],
  "🏠 Home": [
    { id: "h1", name: "Scented Candle",     price: 4000,  stock: 45, emoji: "🕯️" },
    { id: "h2", name: "Throw Pillow",       price: 5500,  stock: 30, emoji: "🛋️" },
    { id: "h3", name: "Desk Organizer",     price: 7000,  stock: 22, emoji: "📦" },
  ],
};

// Flatten all products into a lookup map
const ALL_PRODUCTS = {};
Object.values(CATALOG).forEach((items) =>
  items.forEach((p) => (ALL_PRODUCTS[p.id] = p))
);

// ─────────────────────────────────────────────
//  ORDERS STORE  (in-memory; swap for a DB)
// ─────────────────────────────────────────────
const ORDERS = {};
let orderCounter = 1000;

// ─────────────────────────────────────────────
//  HELPERS
// ─────────────────────────────────────────────
const fmt = (n) => `₦${Number(n).toLocaleString("en-NG")}`;

function getCart(ctx) {
  if (!ctx.session.cart) ctx.session.cart = {};
  return ctx.session.cart;
}

function cartTotal(cart) {
  return Object.entries(cart).reduce((sum, [id, qty]) => {
    return sum + (ALL_PRODUCTS[id]?.price ?? 0) * qty;
  }, 0);
}

function cartSummary(cart) {
  const lines = Object.entries(cart)
    .filter(([, qty]) => qty > 0)
    .map(([id, qty]) => {
      const p = ALL_PRODUCTS[id];
      return `${p.emoji} ${p.name} × ${qty} = ${fmt(p.price * qty)}`;
    });
  return lines.length ? lines.join("\n") : "Your cart is empty.";
}

function mainMenu() {
  return Markup.keyboard([
    ["🛍️ Shop", "🛒 My Cart"],
    ["📦 My Orders", "🔍 Track Order"],
    ["💬 Support", "ℹ️ About"],
  ]).resize();
}

// ─────────────────────────────────────────────
//  BOT SETUP
// ─────────────────────────────────────────────
const bot = new Telegraf(process.env.BOT_TOKEN);
bot.use(session());

// ── /start ──────────────────────────────────
bot.start(async (ctx) => {
  const name = ctx.from.first_name || "Shopper";
  await ctx.replyWithPhoto(
    { url: "https://via.placeholder.com/800x400/1a1a2e/FFD700?text=ShopBot+%F0%9F%9B%8D%EF%B8%8F" },
    {
      caption:
        `👋 *Welcome to ShopBot, ${name}!*\n\n` +
        `Your one-stop shop for fashion, beauty, electronics & home essentials.\n\n` +
        `🚀 Fast delivery across Nigeria\n` +
        `💳 Secure payments\n` +
        `📦 Real-time order tracking\n\n` +
        `Use the menu below to get started!`,
      parse_mode: "Markdown",
      ...mainMenu(),
    }
  );
});

// ── SHOP ─────────────────────────────────────
bot.hears("🛍️ Shop", async (ctx) => {
  const buttons = Object.keys(CATALOG).map((cat) => [
    Markup.button.callback(cat, `cat:${cat}`),
  ]);
  await ctx.reply(
    "🛍️ *Choose a Category:*",
    { parse_mode: "Markdown", ...Markup.inlineKeyboard(buttons) }
  );
});

bot.action(/^cat:(.+)$/, async (ctx) => {
  const cat = ctx.match[1];
  const items = CATALOG[cat];
  if (!items) return ctx.answerCbQuery("Category not found");

  const buttons = items.map((p) => [
    Markup.button.callback(
      `${p.emoji} ${p.name} — ${fmt(p.price)}`,
      `item:${p.id}`
    ),
  ]);
  buttons.push([Markup.button.callback("⬅️ Back to Categories", "back:cats")]);

  await ctx.editMessageText(
    `${cat}\n\nSelect a product to view details:`,
    { ...Markup.inlineKeyboard(buttons) }
  );
  ctx.answerCbQuery();
});

bot.action("back:cats", async (ctx) => {
  const buttons = Object.keys(CATALOG).map((cat) => [
    Markup.button.callback(cat, `cat:${cat}`),
  ]);
  await ctx.editMessageText(
    "🛍️ *Choose a Category:*",
    { parse_mode: "Markdown", ...Markup.inlineKeyboard(buttons) }
  );
  ctx.answerCbQuery();
});

bot.action(/^item:(.+)$/, async (ctx) => {
  const p = ALL_PRODUCTS[ctx.match[1]];
  if (!p) return ctx.answerCbQuery("Product not found");

  const stockStatus =
    p.stock > 10 ? "✅ In Stock" : p.stock > 0 ? `⚠️ Only ${p.stock} left!` : "❌ Out of Stock";

  await ctx.editMessageText(
    `${p.emoji} *${p.name}*\n\n` +
      `💰 Price: *${fmt(p.price)}*\n` +
      `📦 Status: ${stockStatus}\n\n` +
      `Tap below to add to your cart:`,
    {
      parse_mode: "Markdown",
      ...Markup.inlineKeyboard([
        [
          Markup.button.callback("➕ Add to Cart", `add:${p.id}`),
          Markup.button.callback("🛒 View Cart", "viewcart"),
        ],
        [Markup.button.callback("⬅️ Back", `back:cats`)],
      ]),
    }
  );
  ctx.answerCbQuery();
});

// ── ADD TO CART ──────────────────────────────
bot.action(/^add:(.+)$/, async (ctx) => {
  const id = ctx.match[1];
  const p = ALL_PRODUCTS[id];
  if (!p) return ctx.answerCbQuery("Product not found");
  if (p.stock === 0) return ctx.answerCbQuery("❌ Out of stock!");

  const cart = getCart(ctx);
  cart[id] = (cart[id] || 0) + 1;

  await ctx.answerCbQuery(`✅ ${p.name} added to cart!`);
  await ctx.editMessageText(
    `${p.emoji} *${p.name}*\n\n` +
      `💰 Price: *${fmt(p.price)}*\n` +
      `🛒 In your cart: *${cart[id]}*\n\n` +
      `Cart Total: *${fmt(cartTotal(cart))}*`,
    {
      parse_mode: "Markdown",
      ...Markup.inlineKeyboard([
        [
          Markup.button.callback("➕ Add More", `add:${id}`),
          Markup.button.callback("➖ Remove One", `rem:${id}`),
        ],
        [
          Markup.button.callback("🛒 View Cart", "viewcart"),
          Markup.button.callback("🛍️ Keep Shopping", "back:cats"),
        ],
      ]),
    }
  );
});

// ── REMOVE FROM CART ─────────────────────────
bot.action(/^rem:(.+)$/, async (ctx) => {
  const id = ctx.match[1];
  const cart = getCart(ctx);
  if (cart[id] > 0) cart[id]--;
  if (cart[id] === 0) delete cart[id];
  ctx.answerCbQuery("Removed one item.");
  await ctx.editMessageText(
    `Updated cart:\n\n${cartSummary(cart)}\n\n*Total: ${fmt(cartTotal(cart))}*`,
    {
      parse_mode: "Markdown",
      ...Markup.inlineKeyboard([
        [Markup.button.callback("🛒 View Full Cart", "viewcart")],
        [Markup.button.callback("🛍️ Keep Shopping", "back:cats")],
      ]),
    }
  );
});

// ── VIEW CART ────────────────────────────────
bot.hears("🛒 My Cart", async (ctx) => {
  const cart = getCart(ctx);
  const total = cartTotal(cart);
  const empty = Object.keys(cart).length === 0;

  await ctx.reply(
    `🛒 *Your Cart*\n\n${cartSummary(cart)}\n\n` +
      (empty ? "" : `*Total: ${fmt(total)}*`),
    {
      parse_mode: "Markdown",
      ...Markup.inlineKeyboard(
        empty
          ? [[Markup.button.callback("🛍️ Start Shopping", "back:cats")]]
          : [
              [Markup.button.callback("✅ Checkout", "checkout")],
              [Markup.button.callback("🗑️ Clear Cart", "clearcart")],
              [Markup.button.callback("🛍️ Keep Shopping", "back:cats")],
            ]
      ),
    }
  );
});

bot.action("viewcart", async (ctx) => {
  const cart = getCart(ctx);
  const total = cartTotal(cart);
  const empty = Object.keys(cart).length === 0;

  await ctx.editMessageText(
    `🛒 *Your Cart*\n\n${cartSummary(cart)}\n\n` +
      (empty ? "" : `*Total: ${fmt(total)}*`),
    {
      parse_mode: "Markdown",
      ...Markup.inlineKeyboard(
        empty
          ? [[Markup.button.callback("🛍️ Start Shopping", "back:cats")]]
          : [
              [Markup.button.callback("✅ Checkout", "checkout")],
              [Markup.button.callback("🗑️ Clear Cart", "clearcart")],
              [Markup.button.callback("🛍️ Keep Shopping", "back:cats")],
            ]
      ),
    }
  );
  ctx.answerCbQuery();
});

bot.action("clearcart", async (ctx) => {
  ctx.session.cart = {};
  await ctx.editMessageText("🗑️ Cart cleared!", {
    ...Markup.inlineKeyboard([[Markup.button.callback("🛍️ Shop Now", "back:cats")]]),
  });
  ctx.answerCbQuery("Cart cleared.");
});

// ── CHECKOUT ─────────────────────────────────
bot.action("checkout", async (ctx) => {
  const cart = getCart(ctx);
  if (Object.keys(cart).length === 0) {
    return ctx.answerCbQuery("Your cart is empty!");
  }
  ctx.session.checkingOut = true;
  await ctx.editMessageText(
    "📦 *Checkout*\n\nPlease send your *full delivery address* (street, city, state):",
    { parse_mode: "Markdown" }
  );
  ctx.answerCbQuery();
});

// ── COLLECT ADDRESS & CREATE ORDER ───────────
bot.on("text", async (ctx, next) => {
  if (!ctx.session.checkingOut) return next();

  const address = ctx.message.text;
  const cart = getCart(ctx);
  const total = cartTotal(cart);
  const orderId = `ORD-${++orderCounter}`;

  // Save order
  ORDERS[orderId] = {
    id: orderId,
    userId: ctx.from.id,
    name: ctx.from.first_name,
    items: { ...cart },
    address,
    total,
    status: "Confirmed ✅",
    createdAt: new Date().toLocaleString("en-NG", { timeZone: "Africa/Lagos" }),
  };

  // Clear cart & checkout flag
  ctx.session.cart = {};
  ctx.session.checkingOut = false;

  await ctx.reply(
    `🎉 *Order Placed Successfully!*\n\n` +
      `🆔 Order ID: \`${orderId}\`\n` +
      `📦 Items: ${Object.keys(ORDERS[orderId].items).length}\n` +
      `💰 Total: *${fmt(total)}*\n` +
      `📍 Address: ${address}\n\n` +
      `*Payment:* Please make a bank transfer to:\n` +
      `🏦 Bank: First Bank\n` +
      `💳 Account: 1234567890\n` +
      `👤 Name: ShopBot Nigeria Ltd\n\n` +
      `Send proof of payment to @ShopBotSupport\n\n` +
      `Track your order with: /track_${orderId}`,
    { parse_mode: "Markdown", ...mainMenu() }
  );
});

// ── MY ORDERS ────────────────────────────────
bot.hears("📦 My Orders", async (ctx) => {
  const userId = ctx.from.id;
  const myOrders = Object.values(ORDERS).filter((o) => o.userId === userId);

  if (!myOrders.length) {
    return ctx.reply("📦 You have no orders yet.\n\nStart shopping! 🛍️", mainMenu());
  }

  const list = myOrders
    .slice(-5)
    .reverse()
    .map(
      (o) =>
        `🆔 *${o.id}*\n💰 ${fmt(o.total)}\n📌 ${o.status}\n📅 ${o.createdAt}`
    )
    .join("\n\n──────────\n\n");

  await ctx.reply(`📦 *Your Recent Orders:*\n\n${list}`, {
    parse_mode: "Markdown",
    ...mainMenu(),
  });
});

// ── TRACK ORDER ──────────────────────────────
bot.hears("🔍 Track Order", async (ctx) => {
  await ctx.reply(
    "🔍 Enter your Order ID (e.g. `ORD-1001`):",
    { parse_mode: "Markdown" }
  );
  ctx.session.tracking = true;
});

bot.command(/^track_(.+)$/, async (ctx) => {
  const orderId = ctx.match[1];
  showOrder(ctx, orderId);
});

bot.on("text", async (ctx, next) => {
  if (!ctx.session.tracking) return next();
  const orderId = ctx.message.text.trim().toUpperCase();
  ctx.session.tracking = false;
  await showOrder(ctx, orderId);
});

async function showOrder(ctx, orderId) {
  const order = ORDERS[orderId];
  if (!order) {
    return ctx.reply(`❌ Order \`${orderId}\` not found. Check the ID and try again.`, {
      parse_mode: "Markdown",
      ...mainMenu(),
    });
  }

  const itemsList = Object.entries(order.items)
    .map(([id, qty]) => {
      const p = ALL_PRODUCTS[id];
      return `${p.emoji} ${p.name} × ${qty}`;
    })
    .join("\n");

  await ctx.reply(
    `📦 *Order Details*\n\n` +
      `🆔 ID: \`${order.id}\`\n` +
      `📌 Status: *${order.status}*\n` +
      `📅 Date: ${order.createdAt}\n\n` +
      `🛒 Items:\n${itemsList}\n\n` +
      `💰 Total: *${fmt(order.total)}*\n` +
      `📍 Address: ${order.address}`,
    { parse_mode: "Markdown", ...mainMenu() }
  );
}

// ── SUPPORT ──────────────────────────────────
bot.hears("💬 Support", async (ctx) => {
  await ctx.reply(
    "💬 *Customer Support*\n\n" +
      "Need help? We're here for you!\n\n" +
      "📧 Email: support@shopbot.ng\n" +
      "📱 WhatsApp: +234 800 000 0000\n" +
      "🕐 Hours: Mon–Sat, 8am–8pm\n\n" +
      "Or tap below:",
    {
      parse_mode: "Markdown",
      ...Markup.inlineKeyboard([
        [Markup.button.url("💬 Chat on WhatsApp", "https://wa.me/2348000000000")],
        [Markup.button.url("📧 Send Email", "mailto:support@shopbot.ng")],
      ]),
    }
  );
});

// ── ABOUT ────────────────────────────────────
bot.hears("ℹ️ About", async (ctx) => {
  await ctx.reply(
    "ℹ️ *About ShopBot*\n\n" +
      "ShopBot is Nigeria's smartest Telegram shopping bot.\n\n" +
      "🛍️ 100+ products across 4 categories\n" +
      "🚀 Delivery in 1–3 business days\n" +
      "💳 Bank transfer & card payments\n" +
      "📦 Real-time order tracking\n" +
      "🔒 Secure & trusted since 2024\n\n" +
      "_Built with ❤️ for Nigerian shoppers_",
    { parse_mode: "Markdown", ...mainMenu() }
  );
});

// ── SEARCH ───────────────────────────────────
bot.command("search", async (ctx) => {
  const query = ctx.args.join(" ").toLowerCase();
  if (!query) return ctx.reply("Usage: /search sneakers");

  const results = Object.values(ALL_PRODUCTS).filter(
    (p) =>
      p.name.toLowerCase().includes(query) ||
      p.id.toLowerCase().includes(query)
  );

  if (!results.length) return ctx.reply(`❌ No products found for "${query}"`);

  const buttons = results.map((p) => [
    Markup.button.callback(`${p.emoji} ${p.name} — ${fmt(p.price)}`, `item:${p.id}`),
  ]);

  await ctx.reply(`🔍 Found ${results.length} result(s):`, Markup.inlineKeyboard(buttons));
});

// ─────────────────────────────────────────────
//  EXPRESS SERVER + WEBHOOK
// ─────────────────────────────────────────────
const app = express();
app.use(express.json());

const PORT = process.env.PORT || 3000;
const WEBHOOK_URL = process.env.WEBHOOK_URL; // e.g. https://your-app.railway.app

if (WEBHOOK_URL) {
  // Production: use webhook
  app.use(bot.webhookCallback("/webhook"));
  bot.telegram.setWebhook(`${WEBHOOK_URL}/webhook`);
  console.log(`🌐 Webhook set: ${WEBHOOK_URL}/webhook`);
} else {
  // Development: use long polling
  bot.launch();
  console.log("🤖 Bot running in polling mode...");
}

app.get("/", (req, res) => res.send("🤖 ShopBot is running!"));
app.get("/health", (req, res) => res.json({ status: "ok", bot: "ShopBot" }));

app.listen(PORT, () => console.log(`🚀 Server on port ${PORT}`));

// Graceful shutdown
process.once("SIGINT", () => bot.stop("SIGINT"));
process.once("SIGTERM", () => bot.stop("SIGTERM"));
