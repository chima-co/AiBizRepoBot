# 🛍️ ShopBot — Telegram Shopping Bot

A full-featured Telegram shopping bot for Nigerian e-commerce.
Handles product browsing, cart management, checkout, order tracking, and customer support.

---

## ✨ Features

| Feature | Details |
|---|---|
| 🛍️ Product Catalog | 4 categories, 13+ products |
| 🛒 Cart System | Add, remove, clear |
| ✅ Checkout | Address collection + payment info |
| 📦 Order Tracking | Real-time status by order ID |
| 🔍 Search | `/search <keyword>` |
| 💬 Support | WhatsApp + email links |
| 🌐 Webhook Ready | Railway / Render compatible |

---

## 🚀 Quick Start (Local)

```bash
# 1. Clone / download this folder
cd shopbot

# 2. Install dependencies
npm install

# 3. Create your .env file
cp .env.example .env
# Edit .env and add your BOT_TOKEN (leave WEBHOOK_URL blank for local)

# 4. Run locally
npm start
```

---

## 🌐 Deploy to Railway (Recommended — Free)

### Step 1 — Get a Bot Token
1. Open Telegram → search **@BotFather**
2. Send `/newbot` → follow prompts
3. Copy your `BOT_TOKEN`

### Step 2 — Deploy on Railway
1. Go to **[railway.app](https://railway.app)** → Sign up free
2. Click **"New Project"** → **"Deploy from GitHub repo"**
3. Push this folder to a GitHub repo, connect it
4. In Railway dashboard → **Variables** tab, add:
   ```
   BOT_TOKEN = your_token_here
   WEBHOOK_URL = https://your-app-name.up.railway.app
   ```
5. Railway auto-deploys. Your bot is live! 🎉

> 💡 Find your Railway URL in the **Settings → Domains** tab

---

## 🌐 Deploy to Render (Alternative — Free)

1. Go to **[render.com](https://render.com)** → Sign up free
2. Click **"New Web Service"** → Connect your GitHub repo
3. Set:
   - Build Command: `npm install`
   - Start Command: `node bot.js`
4. Add environment variables:
   ```
   BOT_TOKEN = your_token_here
   WEBHOOK_URL = https://your-app-name.onrender.com
   ```
5. Deploy → Done!

---

## ⚙️ Customizing Your Shop

### Add/Edit Products
Open `bot.js` and edit the `CATALOG` object at the top:

```js
const CATALOG = {
  "👗 Fashion": [
    { id: "f1", name: "Classic White Tee", price: 3500, stock: 50, emoji: "👕" },
    // Add more products here...
  ],
  // Add more categories...
};
```

### Update Payment Info
Search for `"Bank Transfer"` section in `bot.js` and update:
```js
`🏦 Bank: Your Bank Name\n`
`💳 Account: Your Account Number\n`
`👤 Name: Your Business Name\n`
```

### Update Support Contacts
Search for `"💬 Customer Support"` and update email/WhatsApp.

---

## 📁 File Structure

```
shopbot/
├── bot.js          ← Main bot code
├── package.json    ← Dependencies
├── railway.toml    ← Railway config
├── render.yaml     ← Render config
├── .env.example    ← Environment template
├── .gitignore
└── README.md
```

---

## 🔌 Bot Commands

| Command | Action |
|---|---|
| `/start` | Welcome screen |
| `/search <keyword>` | Search products |
| `/track_ORD-XXXX` | Track an order |

---

## 🧩 Upgrade Ideas

- 💾 Add MongoDB/PostgreSQL for persistent orders
- 💳 Integrate Paystack/Flutterwave for auto payment verification
- 📊 Add admin panel for order management
- 📬 Send delivery status update notifications
- 🖼️ Add real product images

---

*Built with [Telegraf.js](https://telegraf.js.org/) + Express.js*
