require("dotenv").config();
const { Telegraf, session } = require("telegraf");
const express = require("express");
const { init } = require("./db/database");

if (!process.env.BOT_TOKEN) {
  console.error("❌ BOT_TOKEN is not set. Please configure your .env file.");
  process.exit(1);
}

// Init DB first, then start everything
init().then(() => {
  const bot = new Telegraf(process.env.BOT_TOKEN);
  bot.use(session());

  // Security middleware
  bot.use(async (ctx, next) => { if (!ctx.from) return; return next(); });

  // Register modules
  require("./commands/core").registerCore(bot);
  require("./commands/sales").registerSales(bot);
  require("./commands/inventory").registerInventory(bot);
  require("./commands/operations").registerOperations(bot);
  require("./commands/analytics").registerAnalytics(bot);

  // Global error handler
  bot.catch(async (err, ctx) => {
    console.error(`❌ Bot error [${ctx.updateType}]:`, err.message);
    try {
      await ctx.reply("⚠️ Something went wrong. Please try again or use /start to reset.");
    } catch {}
  });

  // Fallback
  bot.on("text", async (ctx) => {
    await ctx.reply(
      "🤔 I didn't understand that.\n\nUse /menu to see all options.",
      require("./utils/keyboards").mainMenu()
    );
  });

  // Express
  const app = express();
  app.use(express.json());
  const PORT = process.env.PORT || 3000;
  const WEBHOOK_URL = process.env.WEBHOOK_URL;

  if (WEBHOOK_URL) {
    app.use(bot.webhookCallback("/webhook"));
    bot.telegram.setWebhook(`${WEBHOOK_URL}/webhook`).then(() => {
      console.log(`🌐 Webhook: ${WEBHOOK_URL}/webhook`);
    });
  } else {
    bot.launch();
    console.log("🤖 ShopBoss running (polling mode)");
  }

  app.get("/", (req, res) => res.json({ status: "ok", bot: "ShopBoss" }));
  app.get("/health", (req, res) => res.json({ status: "ok" }));
  app.listen(PORT, () => console.log(`🚀 Server on port ${PORT}`));

  try {
    require("./services/jobs").startJobs(bot);
  } catch (e) { console.warn("Jobs skipped:", e.message); }

  process.once("SIGINT", () => bot.stop("SIGINT"));
  process.once("SIGTERM", () => bot.stop("SIGTERM"));
}).catch((err) => {
  console.error("❌ Failed to start ShopBoss:", err.message);
  process.exit(1);
});
